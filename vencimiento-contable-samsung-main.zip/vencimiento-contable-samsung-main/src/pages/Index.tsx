
import { useState, useEffect } from 'react';
import { Calendar, Users, Bell, FileText, Plus, Sparkles, Menu } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import ContributorForm from '@/components/ContributorForm';
import CalendarView from '@/components/CalendarView';
import ContributorsList from '@/components/ContributorsList';
import NotificationCenter from '@/components/NotificationCenter';
import ThemeToggle from '@/components/ThemeToggle';
import { Contributor } from '@/types/contributor';
import { getContributors, getUpcomingDueDates } from '@/utils/storage';
import { useNotifications } from '@/hooks/useNotifications';
import { useIsMobile } from '@/hooks/use-mobile';

const Index = () => {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [contributors, setContributors] = useState<Contributor[]>([]);
  const [upcomingDueDates, setUpcomingDueDates] = useState<any[]>([]);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const { scheduleVencimientoCheck, permission } = useNotifications();
  const isMobile = useIsMobile();

  useEffect(() => {
    loadData();
    
    if (permission === 'granted') {
      const cleanup = scheduleVencimientoCheck();
      return cleanup;
    }
  }, [permission]);

  const loadData = () => {
    const loadedContributors = getContributors();
    const upcoming = getUpcomingDueDates();
    setContributors(loadedContributors);
    setUpcomingDueDates(upcoming);
  };

  const handleContributorAdded = () => {
    loadData();
    setActiveTab('dashboard');
    setMobileMenuOpen(false);
  };

  const navItems = [
    { id: 'dashboard', label: 'Panel', icon: FileText },
    { id: 'calendar', label: 'Calendario', icon: Calendar },
    { id: 'contributors', label: 'Contribuyentes', icon: Users },
    { id: 'add', label: 'Agregar', icon: Plus }
  ];

  const NavigationContent = () => (
    <div className={isMobile ? "flex flex-col space-y-2 p-4" : "flex space-x-8"}>
      {navItems.map(({ id, label, icon: Icon }) => (
        <button
          key={id}
          onClick={() => {
            setActiveTab(id);
            setMobileMenuOpen(false);
          }}
          className={`flex items-center space-x-2 py-3 px-4 rounded-xl font-semibold text-sm transition-all duration-300 hover:scale-105 ${
            activeTab === id
              ? 'bg-cyan-600 text-white shadow-lg shadow-cyan-500/30'
              : 'text-muted-foreground hover:text-foreground hover:bg-accent/50'
          } ${isMobile ? 'w-full justify-start' : ''}`}
        >
          <Icon className={`h-4 w-4 ${activeTab === id ? 'animate-bounce-subtle' : ''}`} />
          <span>{label}</span>
        </button>
      ))}
    </div>
  );

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return (
          <div className="space-y-6 animate-fade-in">
            <div className="mobile-grid">
              <Card className="modern-card hover-lift group">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 mobile-card">
                  <CardTitle className="text-xs sm:text-sm font-semibold text-muted-foreground">Total</CardTitle>
                  <Users className="h-4 w-4 sm:h-5 sm:w-5 text-primary animate-pulse-soft" />
                </CardHeader>
                <CardContent className="mobile-card pt-0">
                  <div className="text-2xl sm:text-3xl font-bold text-gradient">
                    {contributors.length}
                  </div>
                </CardContent>
              </Card>

              <Card className="modern-card hover-lift group">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 mobile-card">
                  <CardTitle className="text-xs sm:text-sm font-semibold text-muted-foreground">Próximos</CardTitle>
                  <Bell className="h-4 w-4 sm:h-5 sm:w-5 text-orange-500 animate-bounce-subtle" />
                </CardHeader>
                <CardContent className="mobile-card pt-0">
                  <div className="text-2xl sm:text-3xl font-bold text-orange-600 dark:text-orange-400">
                    {upcomingDueDates.length}
                  </div>
                </CardContent>
              </Card>

              <Card className="modern-card hover-lift group">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 mobile-card">
                  <CardTitle className="text-xs sm:text-sm font-semibold text-muted-foreground">Este Mes</CardTitle>
                  <Calendar className="h-4 w-4 sm:h-5 sm:w-5 text-emerald-500 animate-pulse-soft" />
                </CardHeader>
                <CardContent className="mobile-card pt-0">
                  <div className="text-2xl sm:text-3xl font-bold text-emerald-600 dark:text-emerald-400">
                    {contributors.filter(c => {
                      const today = new Date();
                      const dueDay = [7, 9, 11, 13, 15, 17, 19, 21, 23, 25][parseInt(c.ci.slice(-1))];
                      return dueDay >= today.getDate();
                    }).length}
                  </div>
                </CardContent>
              </Card>

              <Card className="modern-card hover-lift group">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 mobile-card">
                  <CardTitle className="text-xs sm:text-sm font-semibold text-muted-foreground">Acciones</CardTitle>
                  <Plus className="h-4 w-4 sm:h-5 sm:w-5 text-primary animate-pulse-soft" />
                </CardHeader>
                <CardContent className="mobile-card pt-0">
                  <Button 
                    onClick={() => setActiveTab('add')}
                    className="w-full gradient-emerald text-white button-modern font-semibold text-xs sm:text-sm"
                    size={isMobile ? "sm" : "default"}
                  >
                    <Plus className="h-3 w-3 sm:h-4 sm:w-4 mr-1 sm:mr-2" />
                    Agregar
                  </Button>
                </CardContent>
              </Card>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="modern-card hover-lift">
                <CardHeader className="mobile-card">
                  <CardTitle className="flex items-center gap-2 sm:gap-3 text-base sm:text-lg">
                    <Bell className="h-5 w-5 sm:h-6 sm:w-6 text-orange-500 animate-bounce-subtle" />
                    Próximos Vencimientos
                  </CardTitle>
                  <CardDescription className="font-medium mobile-text">
                    Vencimientos en los próximos 7 días
                  </CardDescription>
                </CardHeader>
                <CardContent className="mobile-card">
                  <NotificationCenter />
                </CardContent>
              </Card>

              <Card className="modern-card hover-lift">
                <CardHeader className="mobile-card">
                  <CardTitle className="flex items-center gap-2 sm:gap-3 text-base sm:text-lg">
                    <Users className="h-5 w-5 sm:h-6 sm:w-6 text-primary animate-pulse-soft" />
                    Recientes
                  </CardTitle>
                  <CardDescription className="font-medium mobile-text">
                    Últimos registrados
                  </CardDescription>
                </CardHeader>
                <CardContent className="mobile-card">
                  <div className="space-y-3 sm:space-y-4">
                    {contributors.slice(-3).reverse().map((contributor, index) => (
                      <div 
                        key={contributor.id} 
                        className="flex items-center justify-between p-3 sm:p-4 border border-border/50 rounded-xl glass-effect hover-lift transition-all duration-300 group"
                        style={{ animationDelay: `${index * 150}ms` }}
                      >
                        <div className="animate-fade-in min-w-0 flex-1">
                          <p className="font-semibold text-foreground group-hover:text-emerald-600 transition-colors duration-300 mobile-text truncate">{contributor.name}</p>
                          <p className="text-xs sm:text-sm text-muted-foreground font-medium">C.I. {contributor.ci}</p>
                        </div>
                        <Badge variant="outline" className="text-emerald-600 border-emerald-300 hover:bg-emerald-50 dark:hover:bg-emerald-950/20 transition-all duration-200 font-medium rounded-lg text-xs ml-2">
                          {contributor.sector}
                        </Badge>
                      </div>
                    ))}
                    {contributors.length === 0 && (
                      <div className="text-center py-6 sm:py-8 animate-fade-in">
                        <Sparkles className="h-10 w-10 sm:h-12 sm:w-12 text-muted-foreground mx-auto mb-4 animate-float" />
                        <p className="text-muted-foreground mobile-text font-medium">
                          No hay contribuyentes registrados
                        </p>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        );
      case 'calendar':
        return <div className="animate-fade-in"><CalendarView contributors={contributors} /></div>;
      case 'contributors':
        return <div className="animate-fade-in"><ContributorsList onUpdate={loadData} /></div>;
      case 'add':
        return <div className="animate-fade-in"><ContributorForm onSuccess={handleContributorAdded} /></div>;
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50/30 to-cyan-50/50 dark:from-slate-900 dark:via-slate-800 dark:to-slate-900 transition-all duration-500">
      {/* Header */}
      <header className="glass-effect border-b backdrop-blur-xl sticky top-0 z-50 border-border/50">
        <div className="mobile-optimized">
          <div className="flex justify-between items-center h-14 sm:h-16">
            <div className="flex items-center space-x-3 sm:space-x-4">
              <div className="flex items-center space-x-2 sm:space-x-3">
                <div className="p-1.5 sm:p-2 bg-gradient-to-br from-cyan-600 to-cyan-700 rounded-xl shadow-lg shadow-cyan-500/30">
                  <FileText className="h-4 w-4 sm:h-6 sm:w-6 text-white" />
                </div>
                <div>
                  <h1 className="text-lg sm:text-xl font-bold bg-gradient-to-r from-cyan-700 to-cyan-600 dark:from-cyan-400 dark:to-cyan-300 bg-clip-text text-transparent">
                    IVA Control Pro
                  </h1>
                  <p className="text-xs text-muted-foreground font-medium hidden sm:block">
                    Sistema de Gestión de Vencimientos
                  </p>
                </div>
              </div>
            </div>
            <div className="flex items-center space-x-2 sm:space-x-4">
              {upcomingDueDates.length > 0 && (
                <Badge className="bg-gradient-to-r from-cyan-600 to-cyan-700 text-white text-xs px-3 py-1 rounded-full shadow-lg shadow-cyan-500/25 animate-bounce-subtle font-semibold">
                  {upcomingDueDates.length}
                </Badge>
              )}
              <ThemeToggle />
              {isMobile && (
                <Sheet open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
                  <SheetTrigger asChild>
                    <Button variant="ghost" size="sm" className="h-9 w-9 p-0">
                      <Menu className="h-5 w-5" />
                    </Button>
                  </SheetTrigger>
                  <SheetContent side="right" className="w-64">
                    <div className="mt-6">
                      <NavigationContent />
                    </div>
                  </SheetContent>
                </Sheet>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Navigation - Desktop */}
      {!isMobile && (
        <nav className="glass-effect border-b backdrop-blur-xl border-border/50">
          <div className="mobile-optimized">
            <NavigationContent />
          </div>
        </nav>
      )}

      {/* Main Content */}
      <main className="mobile-optimized py-4 sm:py-6 lg:py-8">
        {renderContent()}
      </main>
    </div>
  );
};

export default Index;
