
import { Moon, Sun } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useTheme } from '@/contexts/ThemeContext';

const ThemeToggle = () => {
  const { theme, toggleTheme } = useTheme();

  return (
    <Button
      variant="ghost"
      size="sm"
      onClick={toggleTheme}
      className="h-10 w-10 p-0 hover:bg-accent/50 transition-all duration-300 hover:scale-110 active:scale-95 rounded-xl border border-border/50 hover:border-emerald-200 dark:hover:border-emerald-600 hover:shadow-glow"
    >
      {theme === 'light' ? (
        <Moon className="h-4 w-4 text-muted-foreground hover:text-emerald-600 transition-colors duration-300" />
      ) : (
        <Sun className="h-4 w-4 text-emerald-400 hover:text-emerald-300 transition-colors duration-300" />
      )}
      <span className="sr-only">Cambiar tema</span>
    </Button>
  );
};

export default ThemeToggle;
