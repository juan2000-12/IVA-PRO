
import { Wifi, WifiOff } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { useOffline } from '@/hooks/useOffline';

const OfflineIndicator = () => {
  const isOffline = useOffline();

  if (!isOffline) return null;

  return (
    <Badge 
      variant="destructive" 
      className="fixed bottom-4 right-4 z-50 animate-bounce-subtle bg-red-500 text-white"
    >
      <WifiOff className="h-3 w-3 mr-1" />
      Sin conexión
    </Badge>
  );
};

export default OfflineIndicator;
