
import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ChevronLeft, ChevronRight, Calendar as CalendarIcon } from 'lucide-react';
import { Contributor } from '@/types/contributor';
import { getDueDatesForMonth } from '@/utils/storage';

interface CalendarViewProps {
  contributors: Contributor[];
}

const CalendarView = ({ contributors }: CalendarViewProps) => {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [viewMode, setViewMode] = useState<'year' | 'month'>('year');

  const months = [
    'Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio',
    'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'
  ];

  const daysOfWeek = ['Dom', 'Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb'];

  const navigateYear = (direction: 'prev' | 'next') => {
    const newDate = new Date(currentDate);
    newDate.setFullYear(currentDate.getFullYear() + (direction === 'next' ? 1 : -1));
    setCurrentDate(newDate);
  };

  const navigateMonth = (direction: 'prev' | 'next') => {
    const newDate = new Date(currentDate);
    newDate.setMonth(currentDate.getMonth() + (direction === 'next' ? 1 : -1));
    setCurrentDate(newDate);
  };

  const getDaysInMonth = (year: number, month: number) => {
    return new Date(year, month + 1, 0).getDate();
  };

  const getFirstDayOfMonth = (year: number, month: number) => {
    return new Date(year, month, 1).getDay();
  };

  const renderYearView = () => {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {months.map((month, index) => {
          const dueDates = getDueDatesForMonth(currentDate.getFullYear(), index);
          
          return (
            <Card 
              key={month} 
              className="shadow-card hover:shadow-samsung transition-shadow cursor-pointer"
              onClick={() => {
                const newDate = new Date(currentDate);
                newDate.setMonth(index);
                setCurrentDate(newDate);
                setViewMode('month');
              }}
            >
              <CardHeader className="pb-3">
                <CardTitle className="text-lg text-center text-primary-900">
                  {month} {currentDate.getFullYear()}
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-0">
                <div className="space-y-2">
                  {dueDates.length > 0 ? (
                    dueDates.map((due, idx) => (
                      <div key={idx} className="flex items-center justify-between text-sm">
                        <span className="truncate">{due.contributorName}</span>
                        <Badge variant="outline" className="text-xs">
                          {due.contributorCi.slice(-1)} → {new Date(due.date).getDate()}
                        </Badge>
                      </div>
                    ))
                  ) : (
                    <p className="text-muted-foreground text-sm text-center py-2">
                      Sin vencimientos
                    </p>
                  )}
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>
    );
  };

  const renderMonthView = () => {
    const year = currentDate.getFullYear();
    const month = currentDate.getMonth();
    const daysInMonth = getDaysInMonth(year, month);
    const firstDay = getFirstDayOfMonth(year, month);
    const dueDates = getDueDatesForMonth(year, month);
    
    const days = [];
    
    // Empty cells for days before the first day of the month
    for (let i = 0; i < firstDay; i++) {
      days.push(
        <div key={`empty-${i}`} className="calendar-day opacity-50" />
      );
    }
    
    // Days of the month
    for (let day = 1; day <= daysInMonth; day++) {
      const dayDueDates = dueDates.filter(due => new Date(due.date).getDate() === day);
      const hasEvents = dayDueDates.length > 0;
      
      days.push(
        <div
          key={day}
          className={`calendar-day ${hasEvents ? 'has-event' : ''}`}
          title={hasEvents ? dayDueDates.map(d => `${d.contributorName} (C.I. ${d.contributorCi})`).join(', ') : ''}
        >
          <span className="font-medium">{day}</span>
          {hasEvents && (
            <div className="absolute inset-x-1 bottom-1 text-xs">
              <div className="bg-primary-600 text-white rounded px-1 text-center">
                {dayDueDates.length}
              </div>
            </div>
          )}
        </div>
      );
    }

    return (
      <div className="space-y-4">
        <Card className="shadow-samsung">
          <CardHeader>
            <div className="grid grid-cols-7 gap-1">
              {daysOfWeek.map(day => (
                <div key={day} className="text-center font-semibold text-sm py-2 text-muted-foreground">
                  {day}
                </div>
              ))}
            </div>
          </CardHeader>
          <CardContent>
            <div className="calendar-grid">
              {days}
            </div>
          </CardContent>
        </Card>

        {dueDates.length > 0 && (
          <Card className="shadow-card">
            <CardHeader>
              <CardTitle className="text-lg">
                Vencimientos en {months[month]} {year}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {dueDates.map((due, index) => (
                  <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                    <div>
                      <p className="font-medium">{due.contributorName}</p>
                      <p className="text-sm text-muted-foreground">C.I. {due.contributorCi}</p>
                    </div>
                    <div className="text-right">
                      <p className="font-semibold text-primary-700">
                        {new Date(due.date).getDate()} de {months[month]}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        Último dígito: {due.contributorCi.slice(-1)}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    );
  };

  return (
    <div className="space-y-6">
      <Card className="shadow-samsung">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <CalendarIcon className="h-6 w-6 text-primary-600" />
              <div>
                <CardTitle className="text-xl">
                  {viewMode === 'year' ? currentDate.getFullYear() : `${months[currentDate.getMonth()]} ${currentDate.getFullYear()}`}
                </CardTitle>
                <p className="text-sm text-muted-foreground">
                  {viewMode === 'year' ? 'Vista anual de vencimientos' : 'Vista mensual detallada'}
                </p>
              </div>
            </div>
            
            <div className="flex items-center space-x-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setViewMode(viewMode === 'year' ? 'month' : 'year')}
              >
                {viewMode === 'year' ? 'Vista Mensual' : 'Vista Anual'}
              </Button>
              
              <div className="flex items-center space-x-1">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => viewMode === 'year' ? navigateYear('prev') : navigateMonth('prev')}
                >
                  <ChevronLeft className="h-4 w-4" />
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => viewMode === 'year' ? navigateYear('next') : navigateMonth('next')}
                >
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>
        </CardHeader>
      </Card>

      {viewMode === 'year' ? renderYearView() : renderMonthView()}
    </div>
  );
};

export default CalendarView;
