
import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { updateContributor } from '@/utils/storage';
import { Contributor } from '@/types/contributor';
import { useToast } from '@/hooks/use-toast';

interface EditContributorDialogProps {
  contributor: Contributor | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onUpdate: () => void;
}

const EditContributorDialog = ({ contributor, open, onOpenChange, onUpdate }: EditContributorDialogProps) => {
  const [formData, setFormData] = useState({
    name: '',
    ci: '',
    phone: '',
    sector: '',
    email: ''
  });
  const { toast } = useToast();

  useEffect(() => {
    if (contributor) {
      setFormData({
        name: contributor.name,
        ci: contributor.ci,
        phone: contributor.phone,
        sector: contributor.sector,
        email: contributor.email
      });
    }
  }, [contributor]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!contributor) return;

    if (!formData.name.trim() || !formData.ci.trim()) {
      toast({
        title: 'Error',
        description: 'El nombre y la cédula son obligatorios',
        variant: 'destructive'
      });
      return;
    }

    updateContributor(contributor.id, formData);
    
    toast({
      title: 'Contribuyente actualizado',
      description: `${formData.name} ha sido actualizado exitosamente`,
    });
    
    onUpdate();
    onOpenChange(false);
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Editar Contribuyente</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="name">Nombre y Apellido *</Label>
            <Input
              id="name"
              value={formData.name}
              onChange={(e) => handleInputChange('name', e.target.value)}
              placeholder="Ingrese el nombre completo"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="ci">Cédula de Identidad *</Label>
            <Input
              id="ci"
              value={formData.ci}
              onChange={(e) => handleInputChange('ci', e.target.value)}
              placeholder="Ingrese la cédula"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="phone">Teléfono</Label>
            <Input
              id="phone"
              value={formData.phone}
              onChange={(e) => handleInputChange('phone', e.target.value)}
              placeholder="Ingrese el teléfono"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="sector">Sector/Rubro</Label>
            <Select value={formData.sector} onValueChange={(value) => handleInputChange('sector', value)}>
              <SelectTrigger>
                <SelectValue placeholder="Seleccione un sector" />
              </SelectTrigger>
              <SelectContent className="bg-white border shadow-lg z-50">
                <SelectItem value="Comercio">Comercio</SelectItem>
                <SelectItem value="Servicios">Servicios</SelectItem>
                <SelectItem value="Industria">Industria</SelectItem>
                <SelectItem value="Construcción">Construcción</SelectItem>
                <SelectItem value="Transporte">Transporte</SelectItem>
                <SelectItem value="Gastronomía">Gastronomía</SelectItem>
                <SelectItem value="Tecnología">Tecnología</SelectItem>
                <SelectItem value="Salud">Salud</SelectItem>
                <SelectItem value="Educación">Educación</SelectItem>
                <SelectItem value="Agropecuario">Agropecuario</SelectItem>
                <SelectItem value="Otro">Otro</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="email">Email</Label>
            <Input
              id="email"
              type="email"
              value={formData.email}
              onChange={(e) => handleInputChange('email', e.target.value)}
              placeholder="correo@ejemplo.com"
            />
          </div>

          <div className="flex gap-2 pt-4">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)} className="flex-1">
              Cancelar
            </Button>
            <Button type="submit" className="flex-1 bg-primary-900 hover:bg-primary-800">
              Guardar Cambios
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default EditContributorDialog;
