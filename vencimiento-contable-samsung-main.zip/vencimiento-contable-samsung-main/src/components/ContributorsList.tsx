import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Users, Search, Edit, Trash2, Phone, Mail, Calendar } from 'lucide-react';
import { getContributors, deleteContributor } from '@/utils/storage';
import { Contributor } from '@/types/contributor';
import { useToast } from '@/hooks/use-toast';
import EditContributorDialog from './EditContributorDialog';

interface ContributorsListProps {
  onUpdate: () => void;
}

const ContributorsList = ({ onUpdate }: ContributorsListProps) => {
  const [contributors, setContributors] = useState<Contributor[]>(getContributors());
  const [searchTerm, setSearchTerm] = useState('');
  const [sectorFilter, setSectorFilter] = useState('all');
  const [editingContributor, setEditingContributor] = useState<Contributor | null>(null);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const { toast } = useToast();

  const handleDelete = (id: string, name: string) => {
    if (confirm(`¿Está seguro de eliminar a ${name}?`)) {
      deleteContributor(id);
      setContributors(getContributors());
      onUpdate();
      toast({
        title: 'Contribuyente eliminado',
        description: `${name} ha sido eliminado del sistema`,
      });
    }
  };

  const handleEdit = (contributor: Contributor) => {
    setEditingContributor(contributor);
    setIsEditDialogOpen(true);
  };

  const handleEditUpdate = () => {
    setContributors(getContributors());
    onUpdate();
  };

  const filteredContributors = contributors.filter(contributor => {
    const matchesSearch = contributor.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         contributor.ci.includes(searchTerm) ||
                         contributor.email.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesSector = sectorFilter === 'all' || contributor.sector === sectorFilter;
    
    return matchesSearch && matchesSector;
  });

  const sectors = [...new Set(contributors.map(c => c.sector))];

  const getNextDueDate = (contributor: Contributor) => {
    const today = new Date();
    const currentMonth = today.getMonth();
    const currentYear = today.getFullYear();
    
    // Try current month first
    let dueDate = new Date(currentYear, currentMonth, contributor.dueDay);
    
    // If the due date has passed this month, use next month
    if (dueDate < today) {
      dueDate = new Date(currentYear, currentMonth + 1, contributor.dueDay);
    }
    
    return dueDate;
  };

  const getDaysUntilDue = (contributor: Contributor) => {
    const nextDue = getNextDueDate(contributor);
    const today = new Date();
    const diffTime = nextDue.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  };

  return (
    <div className="space-y-6">
      <Card className="shadow-samsung">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="h-5 w-5 text-primary-600" />
            Gestión de Contribuyentes
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col md:flex-row gap-4 mb-6">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Buscar por nombre, C.I. o email..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={sectorFilter} onValueChange={setSectorFilter}>
              <SelectTrigger className="md:w-48">
                <SelectValue placeholder="Filtrar por sector" />
              </SelectTrigger>
              <SelectContent className="bg-white border shadow-lg z-50">
                <SelectItem value="all">Todos los sectores</SelectItem>
                {sectors.map(sector => (
                  <SelectItem key={sector} value={sector}>{sector}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredContributors.map((contributor) => {
              const daysUntilDue = getDaysUntilDue(contributor);
              const nextDue = getNextDueDate(contributor);
              const isUrgent = daysUntilDue <= 2;
              
              return (
                <Card key={contributor.id} className="shadow-card hover:shadow-samsung transition-shadow">
                  <CardContent className="p-4">
                    <div className="space-y-3">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <h3 className="font-semibold text-primary-900">{contributor.name}</h3>
                          <p className="text-sm text-muted-foreground">C.I. {contributor.ci}</p>
                        </div>
                        <Badge 
                          variant={isUrgent ? "destructive" : "outline"}
                          className={isUrgent ? "notification-badge" : ""}
                        >
                          {contributor.sector}
                        </Badge>
                      </div>

                      <div className="space-y-2 text-sm">
                        {contributor.phone && (
                          <div className="flex items-center gap-2 text-muted-foreground">
                            <Phone className="h-4 w-4" />
                            {contributor.phone}
                          </div>
                        )}
                        
                        {contributor.email && (
                          <div className="flex items-center gap-2 text-muted-foreground">
                            <Mail className="h-4 w-4" />
                            {contributor.email}
                          </div>
                        )}
                        
                        <div className="flex items-center gap-2">
                          <Calendar className="h-4 w-4 text-primary-600" />
                          <span className={`font-medium ${isUrgent ? 'text-red-600' : 'text-primary-700'}`}>
                            Próximo vencimiento: {nextDue.toLocaleDateString()}
                          </span>
                        </div>
                        
                        <div className="text-xs text-muted-foreground">
                          {daysUntilDue === 0 ? 'Vence hoy' : 
                           daysUntilDue === 1 ? 'Vence mañana' : 
                           `Faltan ${daysUntilDue} días`}
                        </div>
                      </div>

                      <div className="flex gap-2 pt-2">
                        <Button
                          variant="outline"
                          size="sm"
                          className="flex-1"
                          onClick={() => handleEdit(contributor)}
                        >
                          <Edit className="h-4 w-4 mr-1" />
                          Editar
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          className="text-red-600 hover:bg-red-50"
                          onClick={() => handleDelete(contributor.id, contributor.name)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>

          {filteredContributors.length === 0 && (
            <div className="text-center py-12">
              <Users className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground">
                {contributors.length === 0 
                  ? 'No hay contribuyentes registrados aún'
                  : 'No se encontraron contribuyentes con los filtros aplicados'
                }
              </p>
            </div>
          )}
        </CardContent>
      </Card>

      <EditContributorDialog
        contributor={editingContributor}
        open={isEditDialogOpen}
        onOpenChange={setIsEditDialogOpen}
        onUpdate={handleEditUpdate}
      />
    </div>
  );
};

export default ContributorsList;
