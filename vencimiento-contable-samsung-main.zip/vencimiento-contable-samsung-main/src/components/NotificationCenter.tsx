
import { useEffect, useState } from 'react';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Bell, AlertTriangle, Calendar, X, Smartphone, CheckCircle } from 'lucide-react';
import { getUpcomingDueDates } from '@/utils/storage';
import { DueDate } from '@/types/contributor';
import { useNotifications } from '@/hooks/useNotifications';
import { Capacitor } from '@capacitor/core';

const NotificationCenter = () => {
  const [upcomingDues, setUpcomingDues] = useState<DueDate[]>([]);
  const [dismissedNotifications, setDismissedNotifications] = useState<string[]>([]);
  const [isRequestingPermission, setIsRequestingPermission] = useState(false);
  const { permission, isSupported, requestPermission, scheduleAllNotifications } = useNotifications();

  useEffect(() => {
    loadNotifications();
    
    const interval = setInterval(loadNotifications, 60 * 60 * 1000);
    
    return () => clearInterval(interval);
  }, []);

  const loadNotifications = () => {
    const upcoming = getUpcomingDueDates(7);
    setUpcomingDues(upcoming);
  };

  const handleEnableNotifications = async () => {
    setIsRequestingPermission(true);
    try {
      const result = await requestPermission();
      if (result === 'granted') {
        // Programar todas las notificaciones después de obtener permisos
        await scheduleAllNotifications();
      }
    } catch (error) {
      console.error('Error habilitando notificaciones:', error);
    } finally {
      setIsRequestingPermission(false);
    }
  };

  const dismissNotification = (contributorId: string, date: string) => {
    const notificationId = `${contributorId}-${date}`;
    setDismissedNotifications(prev => [...prev, notificationId]);
  };

  const getNotificationColor = (daysUntilDue: number) => {
    if (daysUntilDue === 0) return 'bg-red-50 dark:bg-red-950/30 border-red-200 dark:border-red-800 text-red-800 dark:text-red-200';
    if (daysUntilDue === 1) return 'bg-orange-50 dark:bg-orange-950/30 border-orange-200 dark:border-orange-800 text-orange-800 dark:text-orange-200';
    if (daysUntilDue <= 3) return 'bg-emerald-50 dark:bg-emerald-950/30 border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-200';
    return 'bg-blue-50 dark:bg-blue-950/30 border-blue-200 dark:border-blue-800 text-blue-800 dark:text-blue-200';
  };

  const getNotificationIcon = (daysUntilDue: number) => {
    if (daysUntilDue <= 1) return <AlertTriangle className="h-4 w-4 animate-pulse" />;
    return <Bell className="h-4 w-4 animate-bounce-subtle" />;
  };

  const visibleNotifications = upcomingDues.filter(due => {
    const notificationId = `${due.contributorId}-${due.date}`;
    return !dismissedNotifications.includes(notificationId);
  });

  const platformText = Capacitor.isNativePlatform() 
    ? 'Habilita las notificaciones para recibir alertas automáticas en tu dispositivo'
    : 'Habilita las notificaciones para recibir alertas automáticas de vencimientos';

  return (
    <div className="space-y-4">
      {/* Notification Permission Banner */}
      {isSupported && permission !== 'granted' && (
        <Alert className="bg-gradient-to-r from-emerald-50 to-blue-50 dark:from-emerald-950/20 dark:to-blue-950/20 border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-200 animate-fade-in rounded-xl">
          <Smartphone className="h-4 w-4 animate-bounce-subtle" />
          <AlertDescription className="flex items-center justify-between">
            <span className="text-sm font-medium">
              {platformText}
            </span>
            <Button 
              size="sm" 
              onClick={handleEnableNotifications}
              disabled={isRequestingPermission}
              className="ml-2 gradient-emerald text-white button-modern hover:shadow-glow font-medium"
            >
              {isRequestingPermission ? 'Solicitando...' : 'Habilitar'}
            </Button>
          </AlertDescription>
        </Alert>
      )}

      {/* Success Message for Granted Permission */}
      {permission === 'granted' && (
        <Alert className="bg-emerald-50 dark:bg-emerald-950/30 border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-200 animate-scale-in rounded-xl">
          <CheckCircle className="h-4 w-4 animate-pulse" />
          <AlertDescription className="text-sm font-medium">
            ✅ Notificaciones habilitadas correctamente. {Capacitor.isNativePlatform() 
              ? 'Recibirás alertas en tu dispositivo Android.' 
              : 'Recibirás alertas automáticas.'}
          </AlertDescription>
        </Alert>
      )}

      {/* Notifications List */}
      <div className="space-y-3">
        {visibleNotifications.length === 0 ? (
          <div className="text-center py-8 animate-fade-in">
            <Calendar className="h-12 w-12 text-muted-foreground mx-auto mb-4 animate-float" />
            <p className="text-muted-foreground text-sm font-medium">
              No hay vencimientos próximos en los siguientes 7 días
            </p>
          </div>
        ) : (
          visibleNotifications.map((due, index) => {
            const dueDate = new Date(due.date);
            const notificationColor = getNotificationColor(due.daysUntilDue);
            const NotificationIcon = () => getNotificationIcon(due.daysUntilDue);
            
            return (
              <Alert 
                key={index} 
                className={`${notificationColor} transition-all duration-300 animate-fade-in hover:scale-[1.02] modern-card rounded-xl`}
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-start space-x-3">
                    <div className="animate-pulse-soft">
                      <NotificationIcon />
                    </div>
                    <div className="flex-1">
                      <AlertDescription className="font-semibold">
                        {due.contributorName}
                      </AlertDescription>
                      <div className="mt-1 space-y-1">
                        <p className="text-xs opacity-90 font-medium">
                          C.I. {due.contributorCi} • Vence: {dueDate.toLocaleDateString()}
                        </p>
                        <Badge 
                          variant={due.daysUntilDue <= 1 ? "destructive" : "secondary"}
                          className="text-xs animate-scale-in font-medium rounded-lg"
                        >
                          {due.daysUntilDue === 0 ? 'Vence hoy' : 
                           due.daysUntilDue === 1 ? 'Vence mañana' : 
                           `Faltan ${due.daysUntilDue} días`}
                        </Badge>
                      </div>
                    </div>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => dismissNotification(due.contributorId, due.date)}
                    className="h-6 w-6 p-0 hover:bg-white/50 dark:hover:bg-black/20 transition-all duration-200 hover:scale-110 active:scale-95 rounded-lg"
                  >
                    <X className="h-3 w-3" />
                  </Button>
                </div>
              </Alert>
            );
          })
        )}
      </div>
    </div>
  );
};

export default NotificationCenter;
