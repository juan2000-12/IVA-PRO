
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { Contributor } from '@/types/contributor';
import { saveContributor, calculateDueDay } from '@/utils/storage';
import { UserPlus, Calculator } from 'lucide-react';

interface ContributorFormProps {
  onSuccess: () => void;
}

const ContributorForm = ({ onSuccess }: ContributorFormProps) => {
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    name: '',
    ci: '',
    phone: '',
    sector: '',
    email: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const validateForm = (): string | null => {
    if (!formData.name.trim()) return 'El nombre y apellido es obligatorio';
    if (!formData.ci.trim()) return 'La cédula de identidad es obligatoria';
    if (!/^\d+$/.test(formData.ci)) return 'La cédula debe contener solo números';
    if (formData.phone && !/^[\d\s\-\+\(\)]+$/.test(formData.phone)) {
      return 'El formato del teléfono no es válido';
    }
    if (formData.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      return 'El formato del email no es válido';
    }
    return null;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    const validationError = validateForm();
    if (validationError) {
      toast({
        title: 'Error de validación',
        description: validationError,
        variant: 'destructive'
      });
      return;
    }

    setIsSubmitting(true);

    try {
      const dueDay = calculateDueDay(formData.ci);
      
      const newContributor: Contributor = {
        id: Date.now().toString(),
        name: formData.name.trim(),
        ci: formData.ci.trim(),
        phone: formData.phone.trim(),
        sector: formData.sector || 'General',
        email: formData.email.trim(),
        dueDay,
        createdAt: new Date().toISOString()
      };

      saveContributor(newContributor);

      toast({
        title: 'Contribuyente registrado exitosamente',
        description: `${newContributor.name} - Vence el día ${dueDay} de cada mes`,
      });

      // Reset form
      setFormData({
        name: '',
        ci: '',
        phone: '',
        sector: '',
        email: ''
      });

      onSuccess();
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Hubo un problema al guardar el contribuyente',
        variant: 'destructive'
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const getDueDay = () => {
    if (formData.ci) {
      return calculateDueDay(formData.ci);
    }
    return null;
  };

  return (
    <div className="max-w-2xl mx-auto">
      <Card className="shadow-samsung">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <UserPlus className="h-5 w-5 text-primary-600" />
            Registrar Nuevo Contribuyente
          </CardTitle>
          <CardDescription>
            Complete los datos del contribuyente para calcular automáticamente su fecha de vencimiento de IVA
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label htmlFor="name">Nombre y Apellido *</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => handleInputChange('name', e.target.value)}
                  placeholder="Ej: Juan Pérez"
                  className="transition-all focus:ring-2 focus:ring-primary-500"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="ci">Cédula de Identidad *</Label>
                <Input
                  id="ci"
                  value={formData.ci}
                  onChange={(e) => handleInputChange('ci', e.target.value)}
                  placeholder="Ej: 12345678"
                  className="transition-all focus:ring-2 focus:ring-primary-500"
                />
                {formData.ci && (
                  <div className="flex items-center gap-2 text-sm text-primary-700 bg-primary-50 p-2 rounded">
                    <Calculator className="h-4 w-4" />
                    Vencimiento automático: día {getDueDay()} de cada mes
                  </div>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="phone">Número de Celular</Label>
                <Input
                  id="phone"
                  value={formData.phone}
                  onChange={(e) => handleInputChange('phone', e.target.value)}
                  placeholder="Ej: +598 99 123 456"
                  className="transition-all focus:ring-2 focus:ring-primary-500"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="sector">Rubro o Actividad</Label>
                <Select value={formData.sector} onValueChange={(value) => handleInputChange('sector', value)}>
                  <SelectTrigger className="transition-all focus:ring-2 focus:ring-primary-500">
                    <SelectValue placeholder="Seleccione un rubro" />
                  </SelectTrigger>
                  <SelectContent className="bg-white border shadow-lg z-50">
                    <SelectItem value="Comercio">Comercio</SelectItem>
                    <SelectItem value="Servicios">Servicios</SelectItem>
                    <SelectItem value="Industria">Industria</SelectItem>
                    <SelectItem value="Construcción">Construcción</SelectItem>
                    <SelectItem value="Transporte">Transporte</SelectItem>
                    <SelectItem value="Tecnología">Tecnología</SelectItem>
                    <SelectItem value="Salud">Salud</SelectItem>
                    <SelectItem value="Educación">Educación</SelectItem>
                    <SelectItem value="Otro">Otro</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2 md:col-span-2">
                <Label htmlFor="email">Correo Electrónico</Label>
                <Input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => handleInputChange('email', e.target.value)}
                  placeholder="Ej: juan.perez@email.com"
                  className="transition-all focus:ring-2 focus:ring-primary-500"
                />
              </div>
            </div>

            <div className="flex gap-4 pt-6">
              <Button
                type="submit"
                disabled={isSubmitting}
                className="flex-1 bg-primary-900 hover:bg-primary-800 transition-colors"
              >
                {isSubmitting ? 'Guardando...' : 'Registrar Contribuyente'}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
};

export default ContributorForm;
