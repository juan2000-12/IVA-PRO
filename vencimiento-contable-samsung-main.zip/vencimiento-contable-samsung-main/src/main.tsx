
import { createRoot } from 'react-dom/client'
import { ThemeProvider } from '@/contexts/ThemeContext'
import App from './App.tsx'
import OfflineIndicator from '@/components/OfflineIndicator'
import { Capacitor } from '@capacitor/core'
import { LocalNotifications } from '@capacitor/local-notifications'
import './index.css'

// Registrar Service Worker para capacidades offline
if ('serviceWorker' in navigator && !Capacitor.isNativePlatform()) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/sw.js')
      .then((registration) => {
        console.log('SW registrado: ', registration);
      })
      .catch((registrationError) => {
        console.log('SW falló al registrarse: ', registrationError);
      });
  });
}

// Configurar listeners de notificaciones en plataforma nativa
if (Capacitor.isNativePlatform()) {
  console.log('Configurando listeners de notificaciones nativas...');
  
  // Listener para cuando se recibe una notificación
  LocalNotifications.addListener('localNotificationReceived', (notification) => {
    console.log('✅ Notificación recibida:', notification);
  });

  // Listener para cuando se toca una notificación
  LocalNotifications.addListener('localNotificationActionPerformed', (notificationAction) => {
    console.log('👆 Acción de notificación realizada:', notificationAction);
    
    // Aquí podrías navegar a una pantalla específica basada en la notificación
    const { notification } = notificationAction;
    if (notification.extra?.type === 'due_date_reminder') {
      // Navegar a la pantalla de vencimientos o contribuyente específico
      console.log('Navegando a recordatorio de vencimiento...');
    }
  });

  // Registrar categorías de notificaciones para mejor organización
  LocalNotifications.registerActionTypes({
    types: [
      {
        id: 'DUE_DATE_REMINDER',
        actions: [
          {
            id: 'view',
            title: 'Ver detalles'
          },
          {
            id: 'dismiss',
            title: 'Descartar'
          }
        ]
      }
    ]
  }).catch(error => {
    console.error('Error registrando tipos de acción:', error);
  });
}

createRoot(document.getElementById("root")!).render(
  <ThemeProvider>
    <App />
    <OfflineIndicator />
  </ThemeProvider>
);
