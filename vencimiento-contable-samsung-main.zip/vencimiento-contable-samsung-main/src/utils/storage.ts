
import { Contributor, DueDate } from '@/types/contributor';

const STORAGE_KEY = 'iva-contributors';

export const saveContributor = (contributor: Contributor): void => {
  const contributors = getContributors();
  contributors.push(contributor);
  localStorage.setItem(STORAGE_KEY, JSON.stringify(contributors));
};

export const getContributors = (): Contributor[] => {
  const stored = localStorage.getItem(STORAGE_KEY);
  return stored ? JSON.parse(stored) : [];
};

export const updateContributor = (id: string, updates: Partial<Contributor>): void => {
  const contributors = getContributors();
  const index = contributors.findIndex(c => c.id === id);
  if (index !== -1) {
    contributors[index] = { ...contributors[index], ...updates };
    localStorage.setItem(STORAGE_KEY, JSON.stringify(contributors));
  }
};

export const deleteContributor = (id: string): void => {
  const contributors = getContributors();
  const filtered = contributors.filter(c => c.id !== id);
  localStorage.setItem(STORAGE_KEY, JSON.stringify(filtered));
};

export const calculateDueDay = (ci: string): number => {
  const lastDigit = parseInt(ci.slice(-1));
  const dueDays = [7, 9, 11, 13, 15, 17, 19, 21, 23, 25];
  return dueDays[lastDigit];
};

export const getUpcomingDueDates = (daysAhead: number = 7): DueDate[] => {
  const contributors = getContributors();
  const today = new Date();
  const upcoming: DueDate[] = [];

  contributors.forEach(contributor => {
    // Check next 3 months for due dates
    for (let monthOffset = 0; monthOffset <= 2; monthOffset++) {
      const checkDate = new Date(today.getFullYear(), today.getMonth() + monthOffset, contributor.dueDay);
      const diffTime = checkDate.getTime() - today.getTime();
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

      if (diffDays >= 0 && diffDays <= daysAhead) {
        upcoming.push({
          contributorId: contributor.id,
          contributorName: contributor.name,
          contributorCi: contributor.ci,
          date: checkDate.toISOString(),
          month: checkDate.getMonth(),
          year: checkDate.getFullYear(),
          daysUntilDue: diffDays
        });
      }
    }
  });

  return upcoming.sort((a, b) => a.daysUntilDue - b.daysUntilDue);
};

export const getDueDatesForMonth = (year: number, month: number): DueDate[] => {
  const contributors = getContributors();
  const dueDates: DueDate[] = [];

  contributors.forEach(contributor => {
    const dueDate = new Date(year, month, contributor.dueDay);
    dueDates.push({
      contributorId: contributor.id,
      contributorName: contributor.name,
      contributorCi: contributor.ci,
      date: dueDate.toISOString(),
      month,
      year,
      daysUntilDue: 0
    });
  });

  return dueDates;
};
