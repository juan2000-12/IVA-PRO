
export interface Contributor {
  id: string;
  name: string;
  ci: string;
  phone: string;
  sector: string;
  email: string;
  dueDay: number;
  createdAt: string;
}

export interface DueDate {
  contributorId: string;
  contributorName: string;
  contributorCi: string;
  date: string;
  month: number;
  year: number;
  daysUntilDue: number;
}
