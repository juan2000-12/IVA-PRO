
import { useEffect, useState } from 'react';
import { getUpcomingDueDates } from '@/utils/storage';
import { DueDate } from '@/types/contributor';
import { useToast } from '@/hooks/use-toast';
import { LocalNotifications } from '@capacitor/local-notifications';
import { Capacitor } from '@capacitor/core';

type PermissionStatus = 'granted' | 'denied' | 'default' | 'prompt';

export const useNotifications = () => {
  const [permission, setPermission] = useState<PermissionStatus>('default');
  const [isSupported, setIsSupported] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    checkNotificationSupport();
  }, []);

  const checkNotificationSupport = async () => {
    if (Capacitor.isNativePlatform()) {
      // En plataforma nativa (Android/iOS)
      setIsSupported(true);
      try {
        const status = await LocalNotifications.checkPermissions();
        console.log('Estado de permisos nativos:', status);
        
        // Mapear el estado de permisos de Capacitor a nuestro tipo
        const mappedPermission: PermissionStatus = status.display === 'granted' ? 'granted' : 
                                status.display === 'denied' ? 'denied' : 'default';
        setPermission(mappedPermission);
      } catch (error) {
        console.error('Error checking native notification permissions:', error);
        setIsSupported(false);
      }
    } else {
      // En navegador web
      setIsSupported('Notification' in window);
      if ('Notification' in window) {
        console.log('Estado de permisos web:', Notification.permission);
        
        // Mapear el estado de permisos web a nuestro tipo
        const webPermission: PermissionStatus = Notification.permission === 'granted' ? 'granted' :
                             Notification.permission === 'denied' ? 'denied' : 
                             Notification.permission === 'default' ? 'default' : 'prompt';
        setPermission(webPermission);
      }
    }
  };

  const requestPermission = async (): Promise<'granted' | 'denied'> => {
    if (!isSupported) {
      toast({
        title: 'Notificaciones no soportadas',
        description: 'Tu dispositivo no soporta notificaciones',
        variant: 'destructive'
      });
      return 'denied';
    }
    
    try {
      if (Capacitor.isNativePlatform()) {
        console.log('Solicitando permisos en plataforma nativa...');
        
        // Solicitar permisos en plataforma nativa
        const status = await LocalNotifications.requestPermissions();
        console.log('Respuesta de permisos:', status);
        
        const result: 'granted' | 'denied' = status.display === 'granted' ? 'granted' : 'denied';
        setPermission(result);
        
        if (result === 'granted') {
          toast({
            title: '¡Notificaciones habilitadas!',
            description: 'Recibirás alertas de vencimientos importantes',
          });
          
          // Programar notificaciones inmediatamente
          await scheduleAllNotifications();
          
          // Enviar notificación de prueba
          await sendTestNotification();
        } else {
          toast({
            title: 'Notificaciones denegadas',
            description: 'Para habilitar las notificaciones, ve a la configuración de la aplicación',
            variant: 'destructive'
          });
        }
        
        return result;
      } else {
        console.log('Solicitando permisos en navegador web...');
        
        // Solicitar permisos en navegador web
        const webResult = await Notification.requestPermission();
        const result: 'granted' | 'denied' = webResult === 'granted' ? 'granted' : 'denied';
        setPermission(result);
        
        if (result === 'granted') {
          toast({
            title: '¡Notificaciones habilitadas!',
            description: 'Recibirás alertas de vencimientos importantes',
          });
          
          // Enviar notificación de prueba en web
          new Notification('IVA Control Pro', {
            body: 'Las notificaciones están funcionando correctamente ✅',
            icon: '/favicon.ico',
            tag: 'test-notification'
          });
        } else {
          toast({
            title: 'Notificaciones denegadas',
            description: 'Para habilitar las notificaciones, ve a la configuración de tu navegador',
            variant: 'destructive'
          });
        }
        
        return result;
      }
    } catch (error) {
      console.error('Error al solicitar permisos de notificación:', error);
      toast({
        title: 'Error',
        description: 'No se pudo habilitar las notificaciones',
        variant: 'destructive'
      });
      return 'denied';
    }
  };

  const sendTestNotification = async () => {
    if (!Capacitor.isNativePlatform()) return;
    
    try {
      await LocalNotifications.schedule({
        notifications: [{
          id: 999999,
          title: '🎉 ¡Notificaciones Activadas!',
          body: 'IVA Control Pro está listo para notificarte sobre vencimientos importantes',
          schedule: { at: new Date(Date.now() + 2000) }, // 2 segundos después
          sound: 'default',
          attachments: [],
          actionTypeId: '',
          extra: {
            type: 'test'
          }
        }]
      });
      console.log('Notificación de prueba programada');
    } catch (error) {
      console.error('Error enviando notificación de prueba:', error);
    }
  };

  const scheduleAllNotifications = async () => {
    if (!isSupported || permission !== 'granted') {
      console.log('No se pueden programar notificaciones - permisos no concedidos');
      return;
    }

    try {
      if (Capacitor.isNativePlatform()) {
        console.log('Programando notificaciones nativas...');
        
        // Cancelar todas las notificaciones programadas anteriormente
        await LocalNotifications.cancel({ notifications: [] });
        
        const upcoming = getUpcomingDueDates(30); // Próximos 30 días
        const notifications = [];
        
        upcoming.forEach((due: DueDate, index: number) => {
          const dueDate = new Date(due.date);
          const now = new Date();
          
          // Programar notificaciones para diferentes momentos
          const notificationSchedules = [
            { days: 7, title: '📅 Recordatorio IVA', time: '09:00' },
            { days: 3, title: '⚠️ IVA en 3 días', time: '10:00' },
            { days: 1, title: '🚨 IVA MAÑANA', time: '08:00' },
            { days: 0, title: '🔴 IVA VENCE HOY', time: '07:00' }
          ];
          
          notificationSchedules.forEach((schedule, scheduleIndex) => {
            const notificationDate = new Date(dueDate);
            notificationDate.setDate(notificationDate.getDate() - schedule.days);
            notificationDate.setHours(parseInt(schedule.time.split(':')[0]), parseInt(schedule.time.split(':')[1]), 0, 0);
            
            if (notificationDate > now) {
              const notificationId = (index * 10) + scheduleIndex + 1;
              notifications.push({
                id: notificationId,
                title: schedule.title,
                body: `${due.contributorName} (C.I. ${due.contributorCi})`,
                schedule: { at: notificationDate },
                sound: 'default',
                attachments: [],
                actionTypeId: '',
                extra: {
                  contributorId: due.contributorId,
                  dueDate: due.date,
                  type: 'due_date_reminder'
                }
              });
            }
          });
        });
        
        if (notifications.length > 0) {
          await LocalNotifications.schedule({ notifications });
          console.log(`✅ Programadas ${notifications.length} notificaciones`);
          
          toast({
            title: 'Notificaciones programadas',
            description: `Se programaron ${notifications.length} recordatorios de vencimientos`,
          });
        } else {
          console.log('No hay vencimientos próximos para notificar');
        }
      }
    } catch (error) {
      console.error('Error programando notificaciones:', error);
      toast({
        title: 'Error',
        description: 'No se pudieron programar las notificaciones',
        variant: 'destructive'
      });
    }
  };

  const sendNotification = async (title: string, body: string): Promise<boolean> => {
    if (!isSupported || permission !== 'granted') {
      console.log('No se puede enviar notificación - permisos no concedidos');
      return false;
    }

    try {
      if (Capacitor.isNativePlatform()) {
        await LocalNotifications.schedule({
          notifications: [{
            id: Date.now(),
            title,
            body,
            schedule: { at: new Date(Date.now() + 1000) }, // 1 segundo después
            sound: 'default',
            attachments: [],
            actionTypeId: '',
            extra: {
              type: 'manual_notification'
            }
          }]
        });
        return true;
      } else {
        // Notificación web
        const notification = new Notification(title, {
          body,
          icon: '/favicon.ico',
          badge: '/favicon.ico',
          tag: `notification-${Date.now()}`
        });
        
        setTimeout(() => notification.close(), 8000);
        return true;
      }
    } catch (error) {
      console.error('Error enviando notificación:', error);
      return false;
    }
  };

  const scheduleVencimientoCheck = () => {
    if (!isSupported || permission !== 'granted') return;

    console.log('Iniciando verificación programada de vencimientos...');
    
    // Programar todas las notificaciones al inicio
    scheduleAllNotifications();

    // Verificar cada hora si hay nuevos vencimientos
    const hourlyCheck = setInterval(() => {
      console.log('Verificación horaria de vencimientos...');
      scheduleAllNotifications();
    }, 60 * 60 * 1000);
    
    return () => {
      clearInterval(hourlyCheck);
    };
  };

  return {
    permission,
    isSupported,
    requestPermission,
    sendNotification,
    scheduleVencimientoCheck,
    scheduleAllNotifications
  };
};
