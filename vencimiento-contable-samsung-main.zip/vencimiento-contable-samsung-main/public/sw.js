
importScripts('https://storage.googleapis.com/workbox-cdn/releases/6.4.1/workbox-sw.js');

if (workbox) {
  console.log('Workbox cargado correctamente');

  // Precache de archivos estáticos
  workbox.precaching.precacheAndRoute(self.__WB_MANIFEST);

  // Cache de imágenes
  workbox.routing.registerRoute(
    ({ request }) => request.destination === 'image',
    new workbox.strategies.CacheFirst({
      cacheName: 'images',
      plugins: [
        {
          cacheKeyWillBeUsed: async ({ request }) => request.url,
        },
      ],
    })
  );

  // Cache de API calls con NetworkFirst para datos dinámicos
  workbox.routing.registerRoute(
    ({ url }) => url.pathname.startsWith('/api/'),
    new workbox.strategies.NetworkFirst({
      cacheName: 'api-cache',
      networkTimeoutSeconds: 3,
      plugins: [
        {
          cacheWillUpdate: async ({ response }) => {
            return response.status === 200 ? response : null;
          },
        },
      ],
    })
  );

  // Cache de recursos estáticos con StaleWhileRevalidate
  workbox.routing.registerRoute(
    ({ request }) => 
      request.destination === 'script' ||
      request.destination === 'style' ||
      request.destination === 'font',
    new workbox.strategies.StaleWhileRevalidate({
      cacheName: 'static-resources',
    })
  );

  // Cache de la aplicación principal
  workbox.routing.registerRoute(
    ({ request }) => request.mode === 'navigate',
    new workbox.strategies.NetworkFirst({
      cacheName: 'pages',
      plugins: [
        {
          cacheWillUpdate: async ({ response }) => {
            return response.status === 200 ? response : null;
          },
        },
      ],
    })
  );

} else {
  console.log('Workbox no se pudo cargar');
}
